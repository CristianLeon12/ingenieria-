class Nodo {
    public Nodo   next;
    public int    datos;
    public String nombre;
    
    public Nodo(int d, String n) {
     next   = null;
     datos  = d;
     nombre = n;
    }
}
